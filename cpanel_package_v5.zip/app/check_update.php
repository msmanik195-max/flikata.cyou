<?php
/**
 * In-App Software Update Check API Endpoint
 * Flikata API
 */

header('Content-Type: application/json; charset=UTF-8');
require_once __DIR__ . '/../config/db.php';
$pdo = getDB();

$currentVersionCode = (int)($_GET['current_version_code'] ?? ($_POST['current_version_code'] ?? 0));

try {
    // Fetch latest active release
    $stmt = $pdo->query("SELECT * FROM `app_updates` WHERE `is_active` = 1 ORDER BY `version_code` DESC, `id` DESC LIMIT 1");
    $latest = $stmt ? $stmt->fetch() : null;

    if ($latest) {
        $latestCode = (int)$latest['version_code'];
        $apkUrl = trim((string)($latest['apk_url'] ?? ''));
        $hasUpdate = ($latestCode > $currentVersionCode && !empty($apkUrl));

        echo json_encode([
            'success' => true,
            'update_available' => $hasUpdate,
            'is_force' => ((int)$latest['is_force_update'] === 1),
            'latest_version_code' => $latestCode,
            'latest_version_name' => (string)($latest['version_name'] ?? ''),
            'apk_url' => $apkUrl,
            'apk_size_mb' => (string)($latest['apk_size_mb'] ?? '30 MB'),
            'release_notes' => (string)($latest['release_notes'] ?? 'General improvements and bug fixes.'),
            'message' => $hasUpdate ? 'New update available' : 'App is up to date'
        ], JSON_UNESCAPED_UNICODE);
        exit;
    }

    echo json_encode([
        'success' => true,
        'update_available' => false,
        'is_force' => false,
        'latest_version_code' => $currentVersionCode,
        'latest_version_name' => '6.0',
        'apk_url' => '',
        'apk_size_mb' => '',
        'release_notes' => '',
        'message' => 'No updates configured yet.'
    ]);
} catch (Exception $e) {
    echo json_encode([
        'success' => false,
        'update_available' => false,
        'message' => 'Error checking for updates: ' . $e->getMessage()
    ]);
}
