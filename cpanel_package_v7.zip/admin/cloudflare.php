<?php
/**
 * Cloudflare R2 Multi-Bucket & Storage Management
 * Flikata Admin Control Panel
 */
require_once __DIR__ . '/includes/db.php';
checkAdminAuth();

// Ensure storage_buckets table exists
try {
    $pdo->exec("CREATE TABLE IF NOT EXISTS `storage_buckets` (
      `id` INT AUTO_INCREMENT PRIMARY KEY,
      `bucket_name` VARCHAR(100) NOT NULL,
      `account_id` VARCHAR(100) NOT NULL,
      `access_key_id` VARCHAR(150) NOT NULL,
      `secret_access_key` VARCHAR(255) NOT NULL,
      `public_domain` VARCHAR(255) DEFAULT '',
      `endpoint_url` VARCHAR(255) DEFAULT '',
      `storage_limit_gb` INT DEFAULT 10,
      `used_bytes` BIGINT DEFAULT 0,
      `is_active` TINYINT(1) DEFAULT 1,
      `created_at` DATETIME DEFAULT CURRENT_TIMESTAMP,
      `updated_at` DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;");
} catch (Exception $e) {}

$pageTitle = ($currentLang === 'en') ? 'Cloudflare R2 Storage - Flikata Admin' : 'ক্লাউডফ্লেয়ার R2 স্টোরেজ - Flikata Admin';
$pageHeading = ($currentLang === 'en') ? 'Cloudflare R2 Storage Management' : 'ক্লাউডফ্লেয়ার R2 স্টোরেজ ম্যানেজমেন্ট';
$pageSubheading = ($currentLang === 'en') ? 'Manage Cloudflare R2 Buckets, Credentials & Live Connection Test' : 'ক্লাউডফ্লেয়ার R2 বাকেট, এক্সেস কি এবং লাইভ কানেকশন টেস্ট পরিচালনা করুন';

$successMsg = '';
$errorMsg = '';
$testResult = null;

// Handle Delete Bucket
if (isset($_GET['delete_id'])) {
    $delId = (int)$_GET['delete_id'];
    if ($delId > 0) {
        $pdo->prepare("DELETE FROM `storage_buckets` WHERE id = ?")->execute([$delId]);
        header("Location: cloudflare.php?msg=deleted");
        exit;
    }
}

// Handle Toggle Active
if (isset($_GET['toggle_id'])) {
    $togId = (int)$_GET['toggle_id'];
    if ($togId > 0) {
        $stmt = $pdo->prepare("SELECT is_active FROM `storage_buckets` WHERE id = ?");
        $stmt->execute([$togId]);
        $curr = $stmt->fetchColumn();
        $newVal = ($curr == 1) ? 0 : 1;
        $pdo->prepare("UPDATE `storage_buckets` SET is_active = ? WHERE id = ?")->execute([$newVal, $togId]);
        header("Location: cloudflare.php?msg=toggled");
        exit;
    }
}

if (isset($_GET['msg'])) {
    if ($_GET['msg'] === 'deleted') {
        $successMsg = ($currentLang === 'en') ? 'Bucket configuration removed successfully!' : 'বাকেট কনফিগারেশন সফলভাবে মুছে ফেলা হয়েছে!';
    } elseif ($_GET['msg'] === 'toggled') {
        $successMsg = ($currentLang === 'en') ? 'Bucket active status changed successfully!' : 'বাকেটের স্ট্যাটাস সফলভাবে পরিবর্তন করা হয়েছে!';
    }
}

// Handle Form Submission: Save or Update Bucket
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['save_bucket'])) {
    $bucketName = trim($_POST['bucket_name'] ?? '');
    $accountId = trim($_POST['account_id'] ?? '');
    $accessKey = trim($_POST['access_key_id'] ?? '');
    $secretKey = trim($_POST['secret_access_key'] ?? '');
    $publicDomain = rtrim(trim($_POST['public_domain'] ?? ''), '/');
    $storageLimitGb = max(1, (int)($_POST['storage_limit_gb'] ?? 10));
    $isActive = isset($_POST['is_active']) ? 1 : 0;
    $bucketId = (int)($_POST['bucket_id'] ?? 0);

    if (empty($bucketName) || empty($accountId) || empty($accessKey) || empty($secretKey)) {
        $errorMsg = ($currentLang === 'en') ? 'Please fill in all required Cloudflare R2 fields.' : 'অনুগ্রহ করে ক্লাউডফ্লেয়ার R2 এর সকল প্রয়োজনীয় তথ্য প্রদান করুন।';
    } else {
        try {
            if ($bucketId > 0) {
                $stmt = $pdo->prepare("UPDATE `storage_buckets` SET bucket_name = ?, account_id = ?, access_key_id = ?, secret_access_key = ?, public_domain = ?, storage_limit_gb = ?, is_active = ? WHERE id = ?");
                $stmt->execute([$bucketName, $accountId, $accessKey, $secretKey, $publicDomain, $storageLimitGb, $isActive, $bucketId]);
                $successMsg = ($currentLang === 'en') ? 'Cloudflare R2 Bucket settings updated successfully!' : 'ক্লাউডফ্লেয়ার R2 বাকেট তথ্য সফলভাবে আপডেট করা হয়েছে!';
            } else {
                $stmt = $pdo->prepare("INSERT INTO `storage_buckets` (bucket_name, account_id, access_key_id, secret_access_key, public_domain, storage_limit_gb, is_active) VALUES (?, ?, ?, ?, ?, ?, ?)");
                $stmt->execute([$bucketName, $accountId, $accessKey, $secretKey, $publicDomain, $storageLimitGb, $isActive]);
                $successMsg = ($currentLang === 'en') ? 'New Cloudflare R2 Bucket registered successfully!' : 'নতুন ক্লাউডফ্লেয়ার R2 বাকেট সফলভাবে যুক্ত করা হয়েছে!';
            }
        } catch (Exception $e) {
            $errorMsg = 'Database error: ' . $e->getMessage();
        }
    }
}

// Handle Test Connection Action
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['test_connection'])) {
    $bucketData = [
        'bucket_name' => trim($_POST['test_bucket_name'] ?? ''),
        'account_id' => trim($_POST['test_account_id'] ?? ''),
        'access_key_id' => trim($_POST['test_access_key_id'] ?? ''),
        'secret_access_key' => trim($_POST['test_secret_access_key'] ?? '')
    ];

    $r2HelperPath = __DIR__ . '/../backend/r2_helper.php';
    if (!file_exists($r2HelperPath)) {
        $r2HelperPath = __DIR__ . '/r2_helper.php';
    }

    if (file_exists($r2HelperPath)) {
        require_once $r2HelperPath;
        if (class_exists('CloudflareR2')) {
            $testResult = CloudflareR2::testBucketConnection($bucketData);
        } else {
            $testResult = ['success' => false, 'message' => 'CloudflareR2 engine class not found.'];
        }
    } else {
        $testResult = ['success' => false, 'message' => 'r2_helper.php file not found.'];
    }
}

// Fetch all configured buckets
$buckets = [];
try {
    $stmt = $pdo->query("SELECT * FROM `storage_buckets` ORDER BY `id` DESC");
    $buckets = $stmt ? $stmt->fetchAll(PDO::FETCH_ASSOC) : [];
} catch (Exception $e) {}

// Edit bucket preparation if requested
$editBucket = null;
if (isset($_GET['edit_id'])) {
    $editId = (int)$_GET['edit_id'];
    foreach ($buckets as $b) {
        if ($b['id'] == $editId) {
            $editBucket = $b;
            break;
        }
    }
}

require_once __DIR__ . '/includes/header.php';
?>

<?php if ($successMsg): ?>
    <div class="alert alert-success alert-dismissible fade show d-flex align-items-center mb-4 rounded-3 shadow-sm border-0" role="alert">
        <i class="bi bi-check-circle-fill fs-5 me-2 text-success"></i>
        <div class="fw-semibold"><?= htmlspecialchars($successMsg) ?></div>
        <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
    </div>
<?php endif; ?>

<?php if ($errorMsg): ?>
    <div class="alert alert-danger alert-dismissible fade show d-flex align-items-center mb-4 rounded-3 shadow-sm border-0" role="alert">
        <i class="bi bi-exclamation-triangle-fill fs-5 me-2 text-danger"></i>
        <div class="fw-semibold"><?= htmlspecialchars($errorMsg) ?></div>
        <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
    </div>
<?php endif; ?>

<?php if ($testResult): ?>
    <div class="alert <?= $testResult['success'] ? 'alert-success' : 'alert-danger' ?> alert-dismissible fade show d-flex align-items-center mb-4 rounded-3 shadow-sm border-0" role="alert">
        <i class="bi <?= $testResult['success'] ? 'bi-cloud-check-fill text-success' : 'bi-x-circle-fill text-danger' ?> fs-4 me-3"></i>
        <div>
            <h6 class="fw-bold mb-1"><?= $testResult['success'] ? (($currentLang === 'en') ? 'Connection Succeeded!' : 'কানেকশন সফল হয়েছে!') : (($currentLang === 'en') ? 'Connection Failed!' : 'কানেকশন ব্যর্থ হয়েছে!') ?></h6>
            <div class="small"><?= htmlspecialchars($testResult['message']) ?></div>
        </div>
        <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
    </div>
<?php endif; ?>

<div class="row g-4">
    <!-- R2 Configuration Card -->
    <div class="col-12 col-lg-5">
        <div class="card-custom h-100">
            <div class="d-flex align-items-center gap-2 mb-3">
                <div class="p-2 bg-info-subtle text-info rounded-3">
                    <i class="bi bi-cloud-arrow-up-fill fs-5"></i>
                </div>
                <div>
                    <h6 class="fw-bold text-dark mb-0">
                        <?= $editBucket ? (($currentLang === 'en') ? 'Edit R2 Bucket' : 'বাকেট সম্পাদনা করুন') : (($currentLang === 'en') ? 'Add Cloudflare R2 Bucket' : 'ক্লাউডফ্লেয়ার R2 বাকেট যুক্ত করুন') ?>
                    </h6>
                    <small class="text-muted"><?= ($currentLang === 'en') ? 'Store Media, Videos & APKs securely on Cloudflare' : 'মিডিয়া, ভিডিও ও APK ক্লাউডফ্লেয়ার R2-এ নিরাপদে স্টোর করুন' ?></small>
                </div>
            </div>

            <form method="POST" action="cloudflare.php">
                <input type="hidden" name="save_bucket" value="1">
                <?php if ($editBucket): ?>
                    <input type="hidden" name="bucket_id" value="<?= (int)$editBucket['id'] ?>">
                <?php endif; ?>

                <div class="row g-3">
                    <div class="col-12">
                        <label class="form-label fw-semibold small"><?= ($currentLang === 'en') ? 'Cloudflare Account ID' : 'ক্লাউডফ্লেয়ার একাউন্ট আইডি (Account ID)' ?> <span class="text-danger">*</span></label>
                        <input type="text" name="account_id" class="form-control" placeholder="e.g. 8a34b29c01f..." value="<?= htmlspecialchars($editBucket['account_id'] ?? '') ?>" required>
                    </div>

                    <div class="col-12">
                        <label class="form-label fw-semibold small"><?= ($currentLang === 'en') ? 'R2 Bucket Name' : 'বাকেটের নাম (Bucket Name)' ?> <span class="text-danger">*</span></label>
                        <input type="text" name="bucket_name" class="form-control" placeholder="e.g. flikata-media" value="<?= htmlspecialchars($editBucket['bucket_name'] ?? '') ?>" required>
                    </div>

                    <div class="col-12">
                        <label class="form-label fw-semibold small"><?= ($currentLang === 'en') ? 'Access Key ID' : 'এক্সেস কি আইডি (Access Key ID)' ?> <span class="text-danger">*</span></label>
                        <input type="text" name="access_key_id" class="form-control" placeholder="e.g. 74b8..." value="<?= htmlspecialchars($editBucket['access_key_id'] ?? '') ?>" required>
                    </div>

                    <div class="col-12">
                        <label class="form-label fw-semibold small"><?= ($currentLang === 'en') ? 'Secret Access Key' : 'সিক্রেট এক্সেস কি (Secret Access Key)' ?> <span class="text-danger">*</span></label>
                        <input type="password" name="secret_access_key" class="form-control" placeholder="••••••••••••••••••••••••" value="<?= htmlspecialchars($editBucket['secret_access_key'] ?? '') ?>" required>
                    </div>

                    <div class="col-12">
                        <label class="form-label fw-semibold small"><?= ($currentLang === 'en') ? 'Public Domain / Dev URL' : 'পাবলিক ডোমেইন বা ডেভ URL (Public URL)' ?></label>
                        <input type="url" name="public_domain" class="form-control" placeholder="https://pub-...r2.dev or https://media.yourdomain.com" value="<?= htmlspecialchars($editBucket['public_domain'] ?? '') ?>">
                        <small class="text-muted" style="font-size: 11px;"><?= ($currentLang === 'en') ? 'R2 Public access endpoint used for media display & APK downloads' : 'মিডিয়া প্রদর্শন ও APK ডাউনলোডের জন্য পাবলিক ডোমেইন লিংক' ?></small>
                    </div>

                    <div class="col-md-6">
                        <label class="form-label fw-semibold small"><?= ($currentLang === 'en') ? 'Storage Limit (GB)' : 'স্টোরেজ লিমিট (GB)' ?></label>
                        <input type="number" name="storage_limit_gb" class="form-control" value="<?= (int)($editBucket['storage_limit_gb'] ?? 10) ?>" min="1">
                    </div>

                    <div class="col-md-6 d-flex align-items-center">
                        <div class="form-check form-switch mt-3">
                            <input class="form-check-input" type="checkbox" id="activeSwitch" name="is_active" value="1" <?= (!isset($editBucket) || $editBucket['is_active'] == 1) ? 'checked' : '' ?>>
                            <label class="form-check-label fw-semibold small" for="activeSwitch"><?= ($currentLang === 'en') ? 'Active Bucket' : 'সক্রিয় বাকেট' ?></label>
                        </div>
                    </div>

                    <div class="col-12 mt-4 d-flex gap-2">
                        <button type="submit" class="btn btn-primary flex-grow-1 py-2 fw-semibold">
                            <i class="bi bi-save-fill me-2"></i><?= $editBucket ? (($currentLang === 'en') ? 'Update Bucket' : 'বাকেট আপডেট করুন') : (($currentLang === 'en') ? 'Save Bucket' : 'বাকেট সংরক্ষণ করুন') ?>
                        </button>
                        <?php if ($editBucket): ?>
                            <a href="cloudflare.php" class="btn btn-outline-secondary py-2 px-3"><?= ($currentLang === 'en') ? 'Cancel' : 'বাতিল' ?></a>
                        <?php endif; ?>
                    </div>
                </div>
            </form>
        </div>
    </div>

    <!-- Active Buckets & Live Test Card -->
    <div class="col-12 col-lg-7">
        <div class="card-custom h-100">
            <div class="d-flex align-items-center justify-content-between mb-3">
                <div class="d-flex align-items-center gap-2">
                    <div class="p-2 bg-primary-subtle text-primary rounded-3">
                        <i class="bi bi-server fs-5"></i>
                    </div>
                    <div>
                        <h6 class="fw-bold text-dark mb-0"><?= ($currentLang === 'en') ? 'Configured R2 Buckets' : 'সংযুক্ত ক্লাউডফ্লেয়ার বাকেটসমূহ' ?></h6>
                        <small class="text-muted"><?= count($buckets) ?> <?= ($currentLang === 'en') ? 'buckets registered' : 'টি বাকেট নিবন্ধিত' ?></small>
                    </div>
                </div>
            </div>

            <?php if (empty($buckets)): ?>
                <div class="text-center py-5">
                    <i class="bi bi-clouds fs-1 text-muted d-block mb-2"></i>
                    <h6 class="fw-bold text-secondary"><?= ($currentLang === 'en') ? 'No Cloudflare R2 Buckets Added' : 'এখনও কোনো ক্লাউডফ্লেয়ার বাকেট যুক্ত করা হয়নি' ?></h6>
                    <p class="text-muted small"><?= ($currentLang === 'en') ? 'Fill out the form on the left to connect your Cloudflare R2 bucket.' : 'বাম পাশের ফর্মটি পূরণ করে আপনার ক্লাউডফ্লেয়ার R2 বাকেট যুক্ত করুন।' ?></p>
                </div>
            <?php else: ?>
                <div class="table-responsive">
                    <table class="table table-hover align-middle">
                        <thead class="table-light">
                            <tr style="font-size: 12.5px;">
                                <th><?= ($currentLang === 'en') ? 'Bucket' : 'বাকেট' ?></th>
                                <th><?= ($currentLang === 'en') ? 'Account ID' : 'একাউন্ট আইডি' ?></th>
                                <th><?= ($currentLang === 'en') ? 'Status' : 'স্ট্যাটাস' ?></th>
                                <th><?= ($currentLang === 'en') ? 'Test Ping' : 'লাইভ টেস্ট' ?></th>
                                <th class="text-end"><?= ($currentLang === 'en') ? 'Action' : 'অ্যাকশন' ?></th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach ($buckets as $b): ?>
                                <tr>
                                    <td>
                                        <div class="fw-bold text-dark"><?= htmlspecialchars($b['bucket_name']) ?></div>
                                        <small class="text-muted text-truncate d-block" style="max-width: 180px; font-size: 11px;">
                                            <?= htmlspecialchars($b['public_domain'] ?: 'Default Endpoint') ?>
                                        </small>
                                    </td>
                                    <td>
                                        <span class="badge bg-light text-dark border font-monospace" style="font-size: 11px;">
                                            <?= htmlspecialchars(substr($b['account_id'], 0, 10)) ?>...
                                        </span>
                                    </td>
                                    <td>
                                        <a href="cloudflare.php?toggle_id=<?= (int)$b['id'] ?>" class="text-decoration-none">
                                            <?php if ($b['is_active'] == 1): ?>
                                                <span class="badge bg-success-subtle text-success border border-success-subtle">
                                                    <i class="bi bi-check-circle me-1"></i><?= ($currentLang === 'en') ? 'Active' : 'সক্রিয়' ?>
                                                </span>
                                            <?php else: ?>
                                                <span class="badge bg-secondary-subtle text-secondary border">
                                                    <?= ($currentLang === 'en') ? 'Inactive' : 'নিষ্ক্রিয়' ?>
                                                </span>
                                            <?php endif; ?>
                                        </a>
                                    </td>
                                    <td>
                                        <form method="POST" action="cloudflare.php" class="d-inline">
                                            <input type="hidden" name="test_connection" value="1">
                                            <input type="hidden" name="test_bucket_name" value="<?= htmlspecialchars($b['bucket_name']) ?>">
                                            <input type="hidden" name="test_account_id" value="<?= htmlspecialchars($b['account_id']) ?>">
                                            <input type="hidden" name="test_access_key_id" value="<?= htmlspecialchars($b['access_key_id']) ?>">
                                            <input type="hidden" name="test_secret_access_key" value="<?= htmlspecialchars($b['secret_access_key']) ?>">
                                            <button type="submit" class="btn btn-outline-info btn-sm rounded-pill px-2 py-0.5" style="font-size: 11.5px;" title="Test Connection">
                                                <i class="bi bi-broadcast me-1"></i><?= ($currentLang === 'en') ? 'Ping Test' : 'টেস্ট করুন' ?>
                                            </button>
                                        </form>
                                    </td>
                                    <td class="text-end">
                                        <a href="cloudflare.php?edit_id=<?= (int)$b['id'] ?>" class="btn btn-sm btn-outline-primary p-1 me-1" title="Edit">
                                            <i class="bi bi-pencil-fill"></i>
                                        </a>
                                        <a href="cloudflare.php?delete_id=<?= (int)$b['id'] ?>" class="btn btn-sm btn-outline-danger p-1" title="Delete" onclick="return confirm('<?= ($currentLang === 'en') ? 'Are you sure you want to delete this bucket?' : 'আপনি কি নিশ্চিতভাবে এই বাকেটটি মুছে ফেলতে চান?' ?>');">
                                            <i class="bi bi-trash-fill"></i>
                                        </a>
                                    </td>
                                </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
            <?php endif; ?>
        </div>
    </div>
</div>

<?php require_once __DIR__ . '/includes/footer.php'; ?>
