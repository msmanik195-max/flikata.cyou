<?php
/**
 * App Feature Controls & System Toggles
 * Flikata Admin Control Panel
 * Strictly requires admin authentication.
 */
require_once __DIR__ . '/includes/db.php';
checkAdminAuth();

// Ensure app_feature_settings table exists
try {
    $pdo->exec("CREATE TABLE IF NOT EXISTS `app_feature_settings` (
      `id` INT PRIMARY KEY DEFAULT 1,
      `allow_page_creation` TINYINT(1) NOT NULL DEFAULT 1,
      `allow_login` TINYINT(1) NOT NULL DEFAULT 1,
      `allow_registration` TINYINT(1) NOT NULL DEFAULT 1,
      `allow_chat` TINYINT(1) NOT NULL DEFAULT 1,
      `updated_at` DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;");

    $pdo->exec("INSERT INTO `app_feature_settings` (`id`, `allow_page_creation`, `allow_login`, `allow_registration`, `allow_chat`)
      VALUES (1, 1, 1, 1, 1)
      ON DUPLICATE KEY UPDATE `id` = 1;");
} catch (Exception $e) {}

$pageTitle = ($currentLang === 'en') ? 'App Feature Controls - Flikata Admin' : 'অ্যাপ ফিচার কন্ট্রোল - Flikata Admin';
$pageHeading = ($currentLang === 'en') ? 'App Feature Controls' : 'অ্যাপ ফিচার নিয়ন্ত্রণ';
$pageSubheading = ($currentLang === 'en') ? 'Enable or disable Page Creation, User Login, Registration and Chat System' : 'পেজ তৈরি, ইউজার লগইন, নতুন রেজিস্ট্রেশন এবং চ্যাট অপশন চালু বা বন্ধ করুন';

$successMsg = '';
$errorMsg = '';

// Handle AJAX Single Toggle
if (isset($_GET['ajax_toggle']) && isset($_GET['feature'])) {
    header('Content-Type: application/json; charset=utf-8');
    $feature = trim($_GET['feature']);
    $allowedFeatures = ['allow_page_creation', 'allow_login', 'allow_registration', 'allow_chat'];
    
    if (in_array($feature, $allowedFeatures)) {
        $stmt = $pdo->query("SELECT `{$feature}` FROM app_feature_settings WHERE id = 1");
        $curr = (int)$stmt->fetchColumn();
        $newVal = ($curr === 1) ? 0 : 1;
        $pdo->prepare("UPDATE app_feature_settings SET `{$feature}` = ? WHERE id = 1")->execute([$newVal]);
        echo json_encode(['success' => true, 'feature' => $feature, 'new_value' => $newVal]);
        exit;
    }
    echo json_encode(['success' => false, 'message' => 'Invalid feature']);
    exit;
}

// Handle Form POST Submission (Save all toggles)
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['save_toggles'])) {
    $allowPageCreation = isset($_POST['allow_page_creation']) ? 1 : 0;
    $allowLogin        = isset($_POST['allow_login']) ? 1 : 0;
    $allowRegistration = isset($_POST['allow_registration']) ? 1 : 0;
    $allowChat         = isset($_POST['allow_chat']) ? 1 : 0;

    try {
        $stmt = $pdo->prepare("UPDATE app_feature_settings 
            SET allow_page_creation = ?, allow_login = ?, allow_registration = ?, allow_chat = ? 
            WHERE id = 1");
        $stmt->execute([$allowPageCreation, $allowLogin, $allowRegistration, $allowChat]);
        $successMsg = ($currentLang === 'en') ? 'Feature settings updated successfully!' : 'অ্যাপের ফিচার সেটিংস সফলভাবে সংরক্ষণ করা হয়েছে!';
    } catch (Exception $e) {
        $errorMsg = ($currentLang === 'en') ? ('Error: ' . $e->getMessage()) : ('ত্রুটি: ' . $e->getMessage());
    }
}

// Fetch Current Settings
$stmt = $pdo->query("SELECT * FROM app_feature_settings WHERE id = 1 LIMIT 1");
$settings = $stmt ? $stmt->fetch(PDO::FETCH_ASSOC) : [
    'allow_page_creation' => 1,
    'allow_login'         => 1,
    'allow_registration'  => 1,
    'allow_chat'          => 1
];

require_once __DIR__ . '/includes/header.php';
?>

<?php if ($successMsg): ?>
    <div class="alert alert-success alert-dismissible fade show d-flex align-items-center mb-4 rounded-3 shadow-sm border-0" role="alert">
        <i class="bi bi-check-circle-fill fs-5 me-2 text-success"></i>
        <div class="fw-semibold"><?= htmlspecialchars($successMsg) ?></div>
        <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
    </div>
<?php endif; ?>

<?php if ($errorMsg): ?>
    <div class="alert alert-danger alert-dismissible fade show d-flex align-items-center mb-4 rounded-3 shadow-sm border-0" role="alert">
        <i class="bi bi-exclamation-triangle-fill fs-5 me-2 text-danger"></i>
        <div class="fw-semibold"><?= htmlspecialchars($errorMsg) ?></div>
        <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
    </div>
<?php endif; ?>

<!-- Top Info Banner -->
<div class="card-custom mb-4 p-4 border-0 shadow-sm" style="background: linear-gradient(135deg, #eef2ff 0%, #e0e7ff 100%); border-left: 5px solid #4f46e5 !important;">
    <div class="d-flex align-items-center gap-3">
        <div class="p-3 bg-white text-primary rounded-4 shadow-sm">
            <i class="bi bi-toggles2 fs-2"></i>
        </div>
        <div>
            <h5 class="fw-bold text-dark mb-1">
                <?= ($currentLang === 'en') ? 'Instant App Feature Control' : 'তাৎক্ষণিক অ্যাপ ফিচার নিয়ন্ত্রণ কেন্দ্র' ?>
            </h5>
            <p class="mb-0 text-muted small">
                <?= ($currentLang === 'en') 
                    ? 'Changes made here reflect immediately in the mobile application. When a feature is disabled, users see a clear notice popup.' 
                    : 'এখানে যেকোনো টগল পরিবর্তন করলে মোবাইল অ্যাপ্লিকেশনে তাৎক্ষণিকভাবে কার্যকর হবে। কোনো ফিচার বন্ধ থাকলে অ্যাপে পরিষ্কার পপ-আপ বিজ্ঞপ্তি দেখাবে।' ?>
            </p>
        </div>
    </div>
</div>

<form method="POST" action="feature_controls.php">
    <input type="hidden" name="save_toggles" value="1">

    <div class="row g-4">
        <!-- 1. Page Creation Toggle Card -->
        <div class="col-12 col-md-6">
            <div class="card-custom h-100 p-4 shadow-sm">
                <div class="d-flex align-items-start justify-content-between mb-3">
                    <div class="d-flex align-items-center gap-3">
                        <div class="p-2.5 rounded-3 bg-primary-subtle text-primary">
                            <i class="bi bi-flag-fill fs-4"></i>
                        </div>
                        <div>
                            <h6 class="fw-bold text-dark mb-1"><?= ($currentLang === 'en') ? 'Page Creation' : 'পেজ তৈরি করার অনুমতি' ?></h6>
                            <span class="badge <?= $settings['allow_page_creation'] ? 'bg-success-subtle text-success' : 'bg-danger-subtle text-danger' ?> border">
                                <?= $settings['allow_page_creation'] ? (($currentLang === 'en') ? 'Enabled' : 'চালু আছে') : (($currentLang === 'en') ? 'Disabled' : 'বন্ধ আছে') ?>
                            </span>
                        </div>
                    </div>
                    <div class="form-check form-switch fs-4 mb-0">
                        <input class="form-check-input" type="checkbox" name="allow_page_creation" value="1" id="togglePage" <?= $settings['allow_page_creation'] ? 'checked' : '' ?> onchange="quickToggle('allow_page_creation', this.checked)">
                    </div>
                </div>
                <p class="text-muted small mb-3">
                    <?= ($currentLang === 'en')
                        ? 'When enabled, users can create new community pages. When disabled, users attempting to create a page will receive a notice popup.'
                        : 'এটি চালু থাকলে ব্যবহারকারীরা নতুন পেজ তৈরি করতে পারবে। বন্ধ করা থাকলে অ্যাপে পেজ তৈরি করতে গেলে "পেজ তৈরি করার সুবিধা সাময়িকভাবে বন্ধ আছে।" পপ-আপ দেখাবে।' ?>
                </p>
                <div class="p-2.5 rounded-3 bg-light border small text-secondary">
                    <i class="bi bi-info-circle me-1 text-primary"></i>
                    <?= ($currentLang === 'en') ? 'Notice on block:' : 'বন্ধ থাকলে পপ-আপ মেসেজ:' ?> 
                    <strong class="text-dark">"পেজ তৈরি করার সুবিধা সাময়িকভাবে বন্ধ আছে।"</strong>
                </div>
            </div>
        </div>

        <!-- 2. User Login Toggle Card -->
        <div class="col-12 col-md-6">
            <div class="card-custom h-100 p-4 shadow-sm">
                <div class="d-flex align-items-start justify-content-between mb-3">
                    <div class="d-flex align-items-center gap-3">
                        <div class="p-2.5 rounded-3 bg-info-subtle text-info">
                            <i class="bi bi-box-arrow-in-right fs-4"></i>
                        </div>
                        <div>
                            <h6 class="fw-bold text-dark mb-1"><?= ($currentLang === 'en') ? 'User Login System' : 'ইউজার লগইন সুবিধা' ?></h6>
                            <span class="badge <?= $settings['allow_login'] ? 'bg-success-subtle text-success' : 'bg-danger-subtle text-danger' ?> border">
                                <?= $settings['allow_login'] ? (($currentLang === 'en') ? 'Enabled' : 'চালু আছে') : (($currentLang === 'en') ? 'Disabled' : 'বন্ধ আছে') ?>
                            </span>
                        </div>
                    </div>
                    <div class="form-check form-switch fs-4 mb-0">
                        <input class="form-check-input" type="checkbox" name="allow_login" value="1" id="toggleLogin" <?= $settings['allow_login'] ? 'checked' : '' ?> onchange="quickToggle('allow_login', this.checked)">
                    </div>
                </div>
                <p class="text-muted small mb-3">
                    <?= ($currentLang === 'en')
                        ? 'When enabled, users can log into their accounts. When disabled, login attempts are blocked with an immediate popup notice.'
                        : 'এটি চালু থাকলে ব্যবহারকারীরা নিজ অ্যাকাউন্টে লগইন করতে পারবে। বন্ধ থাকলে অ্যাপে লগইন বাটনে ক্লিক করলে সরাসরি "লগইন সাময়িকভাবে বন্ধ আছে" পপ-আপ মেসেজ আসবে।' ?>
                </p>
                <div class="p-2.5 rounded-3 bg-light border small text-secondary">
                    <i class="bi bi-info-circle me-1 text-info"></i>
                    <?= ($currentLang === 'en') ? 'Notice on block:' : 'বন্ধ থাকলে পপ-আপ মেসেজ:' ?> 
                    <strong class="text-dark">"লগইন সাময়িকভাবে বন্ধ আছে"</strong>
                </div>
            </div>
        </div>

        <!-- 3. User Registration Toggle Card -->
        <div class="col-12 col-md-6">
            <div class="card-custom h-100 p-4 shadow-sm">
                <div class="d-flex align-items-start justify-content-between mb-3">
                    <div class="d-flex align-items-center gap-3">
                        <div class="p-2.5 rounded-3 bg-warning-subtle text-warning">
                            <i class="bi bi-person-plus-fill fs-4"></i>
                        </div>
                        <div>
                            <h6 class="fw-bold text-dark mb-1"><?= ($currentLang === 'en') ? 'New Registration' : 'নতুন একাউন্ট রেজিস্ট্রেশন' ?></h6>
                            <span class="badge <?= $settings['allow_registration'] ? 'bg-success-subtle text-success' : 'bg-danger-subtle text-danger' ?> border">
                                <?= $settings['allow_registration'] ? (($currentLang === 'en') ? 'Enabled' : 'চালু আছে') : (($currentLang === 'en') ? 'Disabled' : 'বন্ধ আছে') ?>
                            </span>
                        </div>
                    </div>
                    <div class="form-check form-switch fs-4 mb-0">
                        <input class="form-check-input" type="checkbox" name="allow_registration" value="1" id="toggleReg" <?= $settings['allow_registration'] ? 'checked' : '' ?> onchange="quickToggle('allow_registration', this.checked)">
                    </div>
                </div>
                <p class="text-muted small mb-3">
                    <?= ($currentLang === 'en')
                        ? 'When enabled, new users can sign up and create accounts. When disabled, registration is halted with a clean notice.'
                        : 'এটি চালু থাকলে নতুন ইউজার সাইন আপ করে একাউন্ট তৈরি করতে পারবে। বন্ধ থাকলে রেজিস্ট্রেশন পেজে সাইন আপে ক্লিক করলে "রেজিস্ট্রেশন সাময়িকভাবে বন্ধ আছে" পপ-আপ আসবে।' ?>
                </p>
                <div class="p-2.5 rounded-3 bg-light border small text-secondary">
                    <i class="bi bi-info-circle me-1 text-warning"></i>
                    <?= ($currentLang === 'en') ? 'Notice on block:' : 'বন্ধ থাকলে পপ-আপ মেসেজ:' ?> 
                    <strong class="text-dark">"রেজিস্ট্রেশন সাময়িকভাবে বন্ধ আছে"</strong>
                </div>
            </div>
        </div>

        <!-- 4. Chat System Toggle Card -->
        <div class="col-12 col-md-6">
            <div class="card-custom h-100 p-4 shadow-sm">
                <div class="d-flex align-items-start justify-content-between mb-3">
                    <div class="d-flex align-items-center gap-3">
                        <div class="p-2.5 rounded-3 bg-success-subtle text-success">
                            <i class="bi bi-chat-dots-fill fs-4"></i>
                        </div>
                        <div>
                            <h6 class="fw-bold text-dark mb-1"><?= ($currentLang === 'en') ? 'Chat Option' : 'চ্যাট অপশন সুবিধা' ?></h6>
                            <span class="badge <?= $settings['allow_chat'] ? 'bg-success-subtle text-success' : 'bg-danger-subtle text-danger' ?> border">
                                <?= $settings['allow_chat'] ? (($currentLang === 'en') ? 'Enabled' : 'চালু আছে') : (($currentLang === 'en') ? 'Disabled' : 'বন্ধ আছে') ?>
                            </span>
                        </div>
                    </div>
                    <div class="form-check form-switch fs-4 mb-0">
                        <input class="form-check-input" type="checkbox" name="allow_chat" value="1" id="toggleChat" <?= $settings['allow_chat'] ? 'checked' : '' ?> onchange="quickToggle('allow_chat', this.checked)">
                    </div>
                </div>
                <p class="text-muted small mb-3">
                    <?= ($currentLang === 'en')
                        ? 'When enabled, real-time messaging and chat conversations function normally. When disabled, chat messaging is restricted with a notice popup.'
                        : 'এটি চালু থাকলে মেসেজিং এবং চ্যাট স্বাভাবিকভাবে কাজ করবে। বন্ধ থাকলে চ্যাট অপশন ব্যবহার বা মেসেজ পাঠাতে গেলে "চ্যাট অপশন সাময়িকভাবে বন্ধ আছে" পপ-আপ দেখাবে।' ?>
                </p>
                <div class="p-2.5 rounded-3 bg-light border small text-secondary">
                    <i class="bi bi-info-circle me-1 text-success"></i>
                    <?= ($currentLang === 'en') ? 'Notice on block:' : 'বন্ধ থাকলে পপ-আপ মেসেজ:' ?> 
                    <strong class="text-dark">"চ্যাট অপশন সাময়িকভাবে বন্ধ আছে"</strong>
                </div>
            </div>
        </div>

        <!-- Submit Button Row -->
        <div class="col-12 mt-2">
            <button type="submit" class="btn btn-primary px-5 py-2.5 rounded-pill fw-bold shadow-sm">
                <i class="bi bi-save2-fill me-2"></i><?= ($currentLang === 'en') ? 'Save All Toggles' : 'সকল পরিবর্তন সংরক্ষণ করুন' ?>
            </button>
        </div>
    </div>
</form>

<script>
function quickToggle(featureName, isChecked) {
    fetch('feature_controls.php?ajax_toggle=1&feature=' + encodeURIComponent(featureName))
        .then(response => response.json())
        .then(data => {
            if (data.success) {
                Swal.fire({
                    toast: true,
                    position: 'top-end',
                    icon: 'success',
                    title: '<?= ($currentLang === 'en') ? 'Setting updated!' : 'সেটিংস আপডেট হয়েছে!' ?>',
                    showConfirmButton: false,
                    timer: 1500
                });
            }
        })
        .catch(err => {
            console.error('Toggle error:', err);
        });
}
</script>

<?php require_once __DIR__ . '/includes/footer.php'; ?>
